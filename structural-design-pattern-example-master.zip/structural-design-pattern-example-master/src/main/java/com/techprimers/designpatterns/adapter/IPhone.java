package com.techprimers.designpatterns.adapter;

public interface IPhone {
    void charge();
}
