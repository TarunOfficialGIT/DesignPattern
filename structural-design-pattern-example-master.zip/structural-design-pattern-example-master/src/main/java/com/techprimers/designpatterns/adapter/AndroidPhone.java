package com.techprimers.designpatterns.adapter;

public interface AndroidPhone {
    void charge();
}
